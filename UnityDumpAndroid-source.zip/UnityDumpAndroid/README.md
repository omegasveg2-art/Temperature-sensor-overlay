# Unity IL2CPP Dumper — Android first-pass build

Android Studio project using Kotlin. It can select `global-metadata.dat` and optionally `libil2cpp.so`, inspect the metadata magic/header, calculate SHA-256, inspect the ELF header/architecture, extract printable ASCII strings, and export a text report through Android's document picker.

## Build APK
- Android Studio (recent stable), Android SDK 35, JDK 17.
- Open this folder in Android Studio and allow Gradle sync.
- Build > Build Bundle(s) / APK(s) > Build APK(s).
- Expected output: `app/build/outputs/apk/debug/app-debug.apk`.

## Test
1. Install the debug APK on Android 8.0+.
2. Select a `global-metadata.dat` file you are authorized to inspect.
3. Optionally select `libil2cpp.so` from the same Unity build.
4. Tap Analyze, then Save report / dump and choose a destination.

## Important scope
This is a first-pass strings dump and file-header inspector, **not** a complete IL2CPP dumper. It does not reconstruct classes/methods/fields from version-specific metadata tables, read a live process, or bypass protections. Strings are heuristic ASCII runs and can include noise or miss UTF-16 strings. The Android app does not require root for files the user can select through the system picker.

## Build through GitHub (no PC required after upload)
1. Create a repository on GitHub (for example `UnityDumpAndroid`).
2. Upload the contents of this project ZIP to the repository root, including the hidden `.github/workflows/build-apk.yml` file. Easiest from a browser: extract the ZIP first on a computer; GitHub's web upload does not always handle folders well. Alternatively use GitHub Codespaces or the GitHub mobile app with a git client.
3. Open the repository's **Actions** tab and select **Build Android APK**. If prompted, enable Actions, then choose **Run workflow**.
4. When the run completes successfully, open the run and download **UnityDumpAndroid-debug-apk** under **Artifacts**. Extract the artifact ZIP to get `app-debug.apk`.
5. Transfer/install the APK on your Android phone. Android may ask you to allow installs from the app you used to open the APK.

The workflow builds a debug APK for testing; it is not a signed release build for Play Store distribution.
