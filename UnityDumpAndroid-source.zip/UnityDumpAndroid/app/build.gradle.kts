plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.morn.il2ppdump"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.morn.il2ppdump"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1-prototype"
    }
}
