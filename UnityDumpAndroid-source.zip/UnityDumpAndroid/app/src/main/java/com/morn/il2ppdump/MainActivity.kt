package com.morn.il2ppdump

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.Typeface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var status: TextView
    private var metadataUri: Uri? = null
    private var libraryUri: Uri? = null
    private var latestReport: String? = null
    private val pickMetadata = 100
    private val pickLibrary = 101
    private val saveReport = 102
    private val magic = 0xFAB11BAF.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFFF7F5FA.toInt())
        }
        root.addView(TextView(this).apply {
            text = "Unity IL2CPP Dumper"
            textSize = 25f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF211B2B.toInt())
        })
        root.addView(TextView(this).apply {
            text = "Android · metadata and ELF inspection"
            textSize = 14f
            setPadding(0, 6, 0, 20)
        })
        root.addView(makeButton("1. Select global-metadata.dat") { chooseFile(pickMetadata) })
        root.addView(makeButton("2. Select libil2cpp.so (optional)") { chooseFile(pickLibrary) })
        root.addView(makeButton("3. Analyze and build text dump") { analyze() })
        root.addView(makeButton("4. Save report / dump…") { saveResult() })
        status = TextView(this).apply {
            textSize = 14f
            setTextColor(0xFF28242F.toInt())
            setPadding(0, 20, 0, 12)
            text = "Select global-metadata.dat to begin.\n\nThis build validates the header and extracts readable strings from the metadata file. It is a useful first-pass dump, not a complete class/method reconstruction."
        }
        val scroll = ScrollView(this)
        scroll.addView(status)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        gravity = Gravity.CENTER
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 8 }
    }

    private fun chooseFile(requestCode: Int) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(intent, requestCode)
    }

    @Deprecated("Legacy callback retained for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            pickMetadata -> { metadataUri = uri; status.text = "Metadata selected:\n$uri\n\nSelect the library if available, then tap Analyze." }
            pickLibrary -> { libraryUri = uri; status.text = "Library selected:\n$uri\n\nTap Analyze to inspect selected files." }
            saveReport -> {
                try {
                    val content = latestReport ?: throw IllegalStateException("Analyze files before saving")
                    contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(content) }
                        ?: throw IllegalStateException("Could not open destination")
                    status.append("\n\nSaved successfully:\n$uri")
                } catch (e: Exception) {
                    status.append("\n\nSave failed: ${e.message ?: e.javaClass.simpleName}")
                }
            }
        }
    }

    private fun analyze() {
        val uri = metadataUri
        if (uri == null) { status.text = "Select global-metadata.dat first."; return }
        status.text = "Reading and analyzing files…"
        try {
            val bytes = contentResolver.openInputStream(uri)?.use { input -> input.readBytes() }
                ?: throw IllegalStateException("Could not read selected metadata file")
            if (bytes.size < 8) throw IllegalArgumentException("File is too small to contain an IL2CPP metadata header")
            val buffer = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
            val foundMagic = buffer.int
            val version = buffer.int
            val validMagic = foundMagic == magic
            val strings = extractStrings(bytes, 4, 3)
            val libInfo = inspectElf(libraryUri)
            val report = buildString {
                appendLine("Unity IL2CPP — Android first-pass dump")
                appendLine("Generated: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())}")
                appendLine("========================================")
                appendLine("Metadata file: ${displayName(uri)}")
                appendLine("Metadata size: ${bytes.size} bytes")
                appendLine("SHA-256: ${sha256(bytes)}")
                appendLine("Magic: 0x${foundMagic.toUInt().toString(16).uppercase(Locale.US)} (expected 0xFAB11BAF)")
                appendLine("Magic check: ${if (validMagic) "PASS" else "FAIL — file may be encrypted, wrapped, or not metadata"}")
                appendLine("Header version field: $version")
                appendLine("Readable strings extracted: ${strings.size}")
                appendLine()
                appendLine("NATIVE LIBRARY")
                appendLine("--------------")
                appendLine(libInfo)
                appendLine()
                appendLine("EXTRACTED STRINGS (first 20,000)")
                appendLine("-------------------------------")
                if (strings.isEmpty()) appendLine("No readable strings found.")
                strings.take(20_000).forEachIndexed { index, item -> appendLine("[$index] offset=0x${item.first.toString(16).uppercase(Locale.US)}  ${item.second}") }
                appendLine()
                appendLine("LIMITATIONS")
                appendLine("-----------")
                appendLine("This is a first-pass strings dump, not a complete IL2CPP metadata parser.")
                appendLine("Class, method, field, type-definition and token reconstruction is not implemented in this build.")
                appendLine("The library inspection reads the selected file header only; it does not attach to a running process.")
            }
            latestReport = report
            status.text = "Analysis complete.\n\nMetadata: ${bytes.size} bytes\nHeader magic: ${if (validMagic) "PASS" else "FAIL"}\nReadable strings: ${strings.size}\nLibrary selected: ${libraryUri != null}\n\nTap ‘Save report / dump…’ to export the text file.\n\nPreview:\n" + report.take(3500)
        } catch (e: Exception) {
            latestReport = null
            status.text = "Analysis failed: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    private fun saveResult() {
        if (latestReport == null) { status.text = "Analyze files first, then save the report."; return }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/plain"
            putExtra(Intent.EXTRA_TITLE, "il2cpp_first_pass_dump.txt")
        }
        startActivityForResult(intent, saveReport)
    }

    private fun extractStrings(bytes: ByteArray, start: Int, minLength: Int): List<Pair<Int, String>> {
        val result = ArrayList<Pair<Int, String>>()
        var i = start
        while (i < bytes.size) {
            val begin = i
            val sb = StringBuilder()
            while (i < bytes.size) {
                val b = bytes[i].toInt() and 0xff
                if (b in 0x20..0x7e) { sb.append(b.toChar()); i++ }
                else if (b == 0 && sb.isNotEmpty()) { i++; break }
                else break
            }
            if (sb.length >= minLength) result.add(begin to sb.toString())
            if (i == begin) i++
        }
        return result
    }

    private fun inspectElf(uri: Uri?): String {
        if (uri == null) return "No libil2cpp.so selected."
        val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes().take(64).toByteArray() }
            ?: return "Could not read native library."
        if (bytes.size < 20) return "File is too small for an ELF header."
        if (bytes[0] != 0x7f.toByte() || bytes[1] != 'E'.code.toByte() || bytes[2] != 'L'.code.toByte() || bytes[3] != 'F'.code.toByte()) {
            return "ELF check: FAIL — selected file does not start with ELF magic."
        }
        val bits = when (bytes[4].toInt() and 0xff) { 1 -> "ELF32"; 2 -> "ELF64"; else -> "unknown ELF class" }
        val endian = when (bytes[5].toInt() and 0xff) { 1 -> "little-endian"; 2 -> "big-endian"; else -> "unknown byte order" }
        val order = if ((bytes[5].toInt() and 0xff) == 2) ByteOrder.BIG_ENDIAN else ByteOrder.LITTLE_ENDIAN
        val machine = ByteBuffer.wrap(bytes).order(order).getShort(18).toInt() and 0xffff
        val arch = when (machine) { 183 -> "AArch64 / arm64"; 40 -> "ARM"; 62 -> "x86-64"; 3 -> "x86"; else -> "machine=$machine" }
        return "ELF check: PASS\nClass: $bits\nByte order: $endian\nArchitecture: $arch\nFile: ${displayName(uri)}"
    }

    private fun displayName(uri: Uri): String = uri.lastPathSegment?.substringAfterLast('/') ?: uri.toString()
    private fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
}
