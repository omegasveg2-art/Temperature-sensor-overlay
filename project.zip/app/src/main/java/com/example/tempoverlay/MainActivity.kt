package com.example.tempoverlay

import android.app.*
import android.content.*
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import java.io.File

/**
 * Единый источник температуры для карточек и кружка.
 * Один таймер читает датчики, одно сглаживание, одно округление —
 * поэтому везде показываются одинаковые цифры в один и тот же момент.
 */
object ThermalStore {
    private const val CPU_PATTERN = "cpu|soc|tsens|cluster|big|little|apc"
    private const val GPU_PATTERN = "gpu"
    private const val SAMPLE_MS = 2000L
    private const val ANIMATE_MS = 200L

    /** Показываемые (сглаженные) значения. -1 = нет данных. */
    var cpu = -1f
        private set
    var gpu = -1f
        private set
    /** false, если CPU-датчиков нет и взята температура батареи. */
    var cpuFromSensor = true
        private set

    private val handler = Handler(Looper.getMainLooper())
    private val observers = LinkedHashSet<() -> Unit>()
    private var appCtx: Context? = null
    private var cpuZones: List<File>? = null
    private var gpuZones: List<File>? = null
    private var targetC = -1f
    private var targetG = -1f

    private val sampler = object : Runnable {
        override fun run() {
            sample()
            handler.postDelayed(this, SAMPLE_MS)
        }
    }

    private val animator = object : Runnable {
        override fun run() {
            animate()
            dispatch()
            handler.postDelayed(this, ANIMATE_MS)
        }
    }

    fun subscribe(ctx: Context, observer: () -> Unit) {
        appCtx = ctx.applicationContext
        val first = observers.isEmpty()
        observers.add(observer)
        if (first) {
            handler.post(sampler)
            handler.post(animator)
        } else {
            observer()
        }
    }

    fun unsubscribe(observer: () -> Unit) {
        observers.remove(observer)
        if (observers.isEmpty()) {
            handler.removeCallbacks(sampler)
            handler.removeCallbacks(animator)
        }
    }

    /** Одинаковое округление для всех мест. */
    fun fmt(v: Float): String = if (v < 0f) "—" else "${Math.round(v)}°"

    private fun dispatch() {
        for (o in observers.toList()) o()
    }

    private fun sample() {
        val c = readMax(zones(CPU_PATTERN, true))
        cpuFromSensor = c != null
        targetC = c ?: batteryTemp()
        if (cpu < 0f) cpu = targetC

        val g = readMax(zones(GPU_PATTERN, false))
        targetG = g ?: -1f
        if (targetG < 0f) gpu = -1f else if (gpu < 0f) gpu = targetG
    }

    private fun animate() {
        if (targetC < 0f) return
        cpu += step(targetC - cpu)
        if (gpu >= 0f && targetG >= 0f) gpu += step(targetG - gpu)
    }

    private fun step(diff: Float) = if (Math.abs(diff) < 0.3f) diff else diff * 0.35f

    // Список подходящих thermal_zone ищем один раз — типы датчиков не меняются.
    private fun zones(names: String, isCpu: Boolean): List<File> {
        (if (isCpu) cpuZones else gpuZones)?.let { return it }
        val pattern = Regex(names)
        val found = File("/sys/class/thermal")
            .listFiles { f -> f.name.startsWith("thermal_zone") }
            ?.filter { z ->
                try {
                    val type = File(z, "type").readText().trim().lowercase()
                    pattern.containsMatchIn(type) && !type.contains("bat")
                } catch (e: Exception) {
                    false
                }
            } ?: emptyList()
        if (isCpu) cpuZones = found else gpuZones = found
        return found
    }

    private fun readMax(zones: List<File>): Float? {
        var best: Float? = null
        for (z in zones) {
            try {
                var v = File(z, "temp").readText().trim().toFloat()
                if (v > 1000f) v /= 1000f else if (v > 150f) v /= 10f
                if (v in 15f..120f && (best == null || v > best)) best = v
            } catch (e: Exception) {
            }
        }
        return best
    }

    private fun batteryTemp(): Float {
        val i = appCtx?.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
    }
}

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var mainBtn: Button
    private lateinit var statusTv: TextView
    private lateinit var cpuTv: TextView
    private lateinit var gpuTv: TextView

    private val ACC = 0xFF4DD0E1.toInt()
    private val BG = 0xFF0F1115.toInt()
    private val CARD = 0xFF181B21.toInt()
    private val MUTED = 0xFF8E9AA3.toInt()

    private val observer: () -> Unit = {
        val c = ThermalStore.fmt(ThermalStore.cpu)
        val g = ThermalStore.fmt(ThermalStore.gpu)
        if (cpuTv.text.toString() != c) cpuTv.text = c
        if (gpuTv.text.toString() != g) gpuTv.text = g
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val dm = resources.displayMetrics
        val d = dm.density
        fun dp(v: Int) = (v * d).toInt()
        val bold = android.graphics.Typeface.DEFAULT_BOLD

        fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }
        fun card() = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(16))
            background = rounded(CARD, 20)
        }
        fun text(t: String, size: Float, color: Int) = TextView(this).apply {
            text = t
            textSize = size
            setTextColor(color)
        }
        fun gap(h: Int) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(h) }

        // ---------- шапка с девушкой ----------
        statusTv = text("○ Выключено", 13f, MUTED).apply {
            setPadding(dp(12), dp(6), dp(12), dp(6))
            background = rounded(0xAA0F1115.toInt(), 50)
            typeface = bold
        }
        val header = FrameLayout(this)
        header.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                o.setRoundRect(0, 0, v.width, v.height, dp(28).toFloat())
            }
        }
        header.clipToOutline = true
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.header_bg)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }, FrameLayout.LayoutParams(-1, -1))
        header.addView(View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0x00000000, 0xE60F1115.toInt())
            )
        }, FrameLayout.LayoutParams(-1, (dm.heightPixels * 0.16f).toInt(), Gravity.BOTTOM))
        header.addView(statusTv, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply {
            setMargins(0, dp(14), dp(14), 0)
        })
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleBox.addView(text("DATCHIK", 30f, Color.WHITE).apply {
            typeface = bold
            letterSpacing = 0.12f
        })
        titleBox.addView(text("@BuxaIich", 15f, ACC).apply { typeface = bold })
        header.addView(titleBox, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START).apply {
            setMargins(dp(20), 0, 0, dp(16))
        })

        // ---------- текущие температуры ----------
        cpuTv = text("—", 30f, Color.WHITE).apply { typeface = bold }
        gpuTv = text("—", 30f, Color.WHITE).apply { typeface = bold }
        fun stat(name: String, value: TextView) = card().apply {
            addView(text(name, 13f, MUTED))
            addView(value)
        }
        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        stats.addView(stat("CPU", cpuTv), LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(6) })
        stats.addView(stat("GPU", gpuTv), LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(6) })

        // ---------- настройки ----------
        val settings = card()
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        val gpuRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val gpuText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        gpuText.addView(text("Учитывать GPU", 16f, Color.WHITE))
        gpuText.addView(text("Показывать видеочип в кружке", 12f, MUTED))
        gpuRow.addView(gpuText, LinearLayout.LayoutParams(0, -2, 1f))
        gpuRow.addView(Switch(this).apply {
            isChecked = prefs.getBoolean("gpu", true)
            thumbTintList = ColorStateList(states, intArrayOf(ACC, 0xFFB0BEC5.toInt()))
            trackTintList = ColorStateList(states, intArrayOf(0x884DD0E1.toInt(), 0x55FFFFFF))
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("gpu", c).apply() }
        })
        settings.addView(gpuRow)

        fun seek(key: String, mn: Int, mx: Int, def: Int, title: String, unit: String) {
            val value = text("${prefs.getInt(key, def)}$unit", 15f, ACC).apply { typeface = bold }
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            row.addView(text(title, 15f, Color.WHITE), LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(value)
            val sb = SeekBar(this)
            sb.progressTintList = ColorStateList.valueOf(ACC)
            sb.thumbTintList = ColorStateList.valueOf(ACC)
            sb.max = mx - mn
            sb.progress = prefs.getInt(key, def) - mn
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = p + mn
                    prefs.edit().putInt(key, v).apply()
                    value.text = "$v$unit"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            settings.addView(row, gap(18))
            settings.addView(sb, gap(4))
        }
        seek("size", 32, 96, 56, "Размер кружка", " dp")
        seek("alpha", 20, 100, 80, "Видимость", "%")

        val hint = text("Кружок можно перетаскивать. Долгое нажатие закрывает его.", 12f, MUTED).apply {
            gravity = Gravity.CENTER
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(16))
        }
        content.addView(header, LinearLayout.LayoutParams(-1, (dm.heightPixels * 0.30f).toInt()))
        content.addView(stats, gap(12))
        content.addView(settings, gap(12))
        content.addView(hint, gap(14))

        // ---------- кнопка внизу ----------
        mainBtn = Button(this).apply {
            textSize = 16f
            typeface = bold
            setTextColor(0xFF06222A.toInt())
            background = rounded(ACC, 18)
        }
        mainBtn.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            } else if (prefs.getBoolean("running", false)) {
                stopService(Intent(this, TempService::class.java))
                prefs.edit().putBoolean("running", false).apply()
            } else {
                startForegroundService(Intent(this, TempService::class.java))
                prefs.edit().putBoolean("running", true).apply()
            }
            refresh()
        }
        val bar = LinearLayout(this).apply {
            setPadding(dp(16), dp(10), dp(16), dp(14))
            setBackgroundColor(BG)
        }
        bar.addView(mainBtn, LinearLayout.LayoutParams(-1, dp(56)))

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
        }
        root.addView(ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(content)
        }, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
        ThermalStore.subscribe(this, observer)
    }

    override fun onPause() {
        ThermalStore.unsubscribe(observer)
        super.onPause()
    }

    private fun refresh() {
        val running = prefs.getBoolean("running", false)
        mainBtn.text = when {
            !Settings.canDrawOverlays(this) -> "Выдать разрешение «Поверх окон»"
            running -> "Остановить"
            else -> "Запустить"
        }
        statusTv.text = if (running) "● Работает" else "○ Выключено"
        statusTv.setTextColor(if (running) ACC else MUTED)
    }
}

class TempService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var root: FrameLayout
    private lateinit var tint: View
    private lateinit var label: TextView

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> applyPrefs() }

    private fun applyPrefs() {
        val d = resources.displayMetrics.density
        val s = (prefs.getInt("size", 56) * d).toInt()
        lp.width = s
        lp.height = s
        root.alpha = prefs.getInt("alpha", 80) / 100f
        if (root.isAttachedToWindow) wm.updateViewLayout(root, lp)
    }

    private var lastSize = -1f
    private val observer: () -> Unit = { render() }

    private fun render() {
        if (!::label.isInitialized) return
        val sC = ThermalStore.cpu
        val sG = ThermalStore.gpu
        if (sC < 0f) return
        val fromSensor = ThermalStore.cpuFromSensor
        val gpuOn = prefs.getBoolean("gpu", true)

        val hot = if (gpuOn && sG >= 0f) maxOf(sC, sG) else sC
        val low = if (fromSensor) 55f else 35f
        val high = if (fromSensor) 70f else 40f
        val color = when {
            hot < low -> 0xFF1E88E5
            hot < high -> 0xFF43A047
            else -> 0xFFE53935
        }.toInt()

        val text: String
        val size: Float
        if (gpuOn) {
            size = 11f
            text = "C ${ThermalStore.fmt(sC)}\nG " + (if (sG >= 0f) ThermalStore.fmt(sG) else "--")
        } else {
            val icon = when {
                hot < low -> "❄️"
                hot < high -> "🌡️"
                else -> "🔥"
            }
            size = 12f
            text = "$icon\n${ThermalStore.fmt(sC)}" + (if (fromSensor) "" else "*")
        }
        if (lastSize != size) { label.textSize = size; lastSize = size }
        if (label.text.toString() != text) label.text = text
        tint.setBackgroundColor(color)
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()

        prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val d = resources.displayMetrics.density
        val size = (prefs.getInt("size", 56) * d).toInt()

        root = FrameLayout(this)
        root.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setOval(0, 0, view.width, view.height)
            }
        }
        root.clipToOutline = true
        root.alpha = prefs.getInt("alpha", 80) / 100f

        val photo = ImageView(this).apply {
            setImageResource(R.drawable.miku_bg)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        tint = View(this).apply { alpha = 0.15f }
        label = TextView(this).apply {
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 12f
            setShadowLayer(6f, 0f, 0f, Color.BLACK)
        }
        root.addView(photo, FrameLayout.LayoutParams(-1, -1))
        root.addView(tint, FrameLayout.LayoutParams(-1, -1))
        root.addView(label, FrameLayout.LayoutParams(-1, -1))

        lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (16 * d).toInt()
            y = (120 * d).toInt()
        }

        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f; var moved = false
        root.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true
                    lp.x = startX + dx
                    lp.y = startY + dy
                    wm.updateViewLayout(root, lp)
                }
                MotionEvent.ACTION_UP ->
                    if (!moved && e.eventTime - e.downTime > 600) stopSelf()
            }
            true
        }

        wm.addView(root, lp)
        prefs.registerOnSharedPreferenceChangeListener(listener)
        ThermalStore.subscribe(this, observer)
    }

    private fun startAsForeground() {
        val channelId = "temp_overlay"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(channelId, "Температура", NotificationManager.IMPORTANCE_MIN)
        )
        val n = Notification.Builder(this, channelId)
            .setContentTitle("Оверлей температуры работает")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    override fun onDestroy() {
        ThermalStore.unsubscribe(observer)
        if (::prefs.isInitialized) {
            prefs.unregisterOnSharedPreferenceChangeListener(listener)
            prefs.edit().putBoolean("running", false).apply()
        }
        if (::root.isInitialized) wm.removeView(root)
        super.onDestroy()
    }
}
