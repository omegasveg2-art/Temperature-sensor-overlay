package com.example.tempoverlay

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import java.io.File

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var mainBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val d = resources.displayMetrics.density
        val pad = (20 * d).toInt()

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        fun label(t: String) = TextView(this).apply {
            text = t
            textSize = 16f
            setPadding(0, (18 * d).toInt(), 0, 0)
        }

        col.addView(TextView(this).apply {
            text = "Temp Overlay"
            textSize = 24f
        })

        mainBtn = Button(this)
        mainBtn.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            } else if (prefs.getBoolean("running", false)) {
                stopService(Intent(this, TempService::class.java))
                prefs.edit().putBoolean("running", false).apply()
            } else {
                startForegroundService(Intent(this, TempService::class.java))
                prefs.edit().putBoolean("running", true).apply()
            }
            refresh()
        }
        col.addView(mainBtn)

        col.addView(label("Датчики"))
        col.addView(Switch(this).apply {
            text = "Учитывать GPU"
            textSize = 16f
            isChecked = prefs.getBoolean("gpu", true)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("gpu", c).apply() }
        })

        fun seek(key: String, mn: Int, mx: Int, def: Int, title: String, unit: String) {
            val tv = label("")
            val sb = SeekBar(this)
            sb.max = mx - mn
            sb.progress = prefs.getInt(key, def) - mn
            tv.text = "$title: ${prefs.getInt(key, def)}$unit"
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = p + mn
                    prefs.edit().putInt(key, v).apply()
                    tv.text = "$title: $v$unit"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            col.addView(tv)
            col.addView(sb)
        }
        seek("size", 32, 96, 56, "Размер кружка", " dp")
        seek("alpha", 20, 100, 80, "Видимость", "%")

        col.addView(label("Долгое нажатие на кружок закрывает его. Кружок можно перетаскивать."))
        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        mainBtn.text = when {
            !Settings.canDrawOverlays(this) -> "Выдать разрешение «Поверх окон»"
            prefs.getBoolean("running", false) -> "Остановить"
            else -> "Запустить"
        }
    }
}

class TempService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var root: FrameLayout
    private lateinit var tint: View
    private lateinit var label: TextView
    private val handler = Handler(Looper.getMainLooper())

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> applyPrefs() }

    private fun applyPrefs() {
        val d = resources.displayMetrics.density
        val s = (prefs.getInt("size", 56) * d).toInt()
        lp.width = s
        lp.height = s
        root.alpha = prefs.getInt("alpha", 80) / 100f
        if (root.isAttachedToWindow) wm.updateViewLayout(root, lp)
    }

    private fun sensorTemp(): Float? {
        val zones = File("/sys/class/thermal").listFiles { f -> f.name.startsWith("thermal_zone") }
            ?: return null
        val names = if (prefs.getBoolean("gpu", true))
            "cpu|gpu|soc|tsens|cluster|big|little|apc"
        else
            "cpu|soc|tsens|cluster|big|little|apc"
        val pattern = Regex(names)
        var best: Float? = null
        for (z in zones) {
            try {
                val type = File(z, "type").readText().trim().lowercase()
                if (!pattern.containsMatchIn(type) || type.contains("bat")) continue
                var v = File(z, "temp").readText().trim().toFloat()
                if (v > 1000f) v /= 1000f else if (v > 150f) v /= 10f
                if (v in 15f..120f && (best == null || v > best!!)) best = v
            } catch (e: Exception) {
            }
        }
        return best
    }

    private fun batteryTemp(): Float {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
    }

    private var target = 0f
    private var shown = -1f
    private var fromSensor = true

    // раз в 2 секунды читаем реальную температуру
    private val tick = object : Runnable {
        override fun run() {
            val s = sensorTemp()
            fromSensor = s != null
            target = s ?: batteryTemp()
            if (shown < 0f) shown = target
            handler.postDelayed(this, 2000)
        }
    }

    // каждые 200 мс плавно, но быстро подтягиваем показание к реальному
    private val animate = object : Runnable {
        override fun run() {
            if (shown >= 0f) {
                val diff = target - shown
                shown += if (Math.abs(diff) < 0.3f) diff else diff * 0.35f
                val low = if (fromSensor) 55f else 35f
                val high = if (fromSensor) 70f else 40f
                val icon = when {
                    shown < low -> "❄️"
                    shown < high -> "🌡️"
                    else -> "🔥"
                }
                val color = when {
                    shown < low -> 0xFF1E88E5
                    shown < high -> 0xFF43A047
                    else -> 0xFFE53935
                }.toInt()
                label.text = "$icon\n${"%.0f".format(shown)}°" + (if (fromSensor) "" else "*")
                tint.setBackgroundColor(color)
            }
            handler.postDelayed(this, 200)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()

        prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val d = resources.displayMetrics.density
        val size = (prefs.getInt("size", 56) * d).toInt()

        root = FrameLayout(this)
        root.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setOval(0, 0, view.width, view.height)
            }
        }
        root.clipToOutline = true
        root.alpha = prefs.getInt("alpha", 80) / 100f

        val photo = ImageView(this).apply {
            setImageResource(R.drawable.miku_bg)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        tint = View(this).apply { alpha = 0.15f }
        label = TextView(this).apply {
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 12f
            setShadowLayer(6f, 0f, 0f, Color.BLACK)
        }
        root.addView(photo, FrameLayout.LayoutParams(-1, -1))
        root.addView(tint, FrameLayout.LayoutParams(-1, -1))
        root.addView(label, FrameLayout.LayoutParams(-1, -1))

        lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (16 * d).toInt()
            y = (120 * d).toInt()
        }

        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f; var moved = false
        root.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true
                    lp.x = startX + dx
                    lp.y = startY + dy
                    wm.updateViewLayout(root, lp)
                }
                MotionEvent.ACTION_UP ->
                    if (!moved && e.eventTime - e.downTime > 600) stopSelf()
            }
            true
        }

        wm.addView(root, lp)
        prefs.registerOnSharedPreferenceChangeListener(listener)
        handler.post(tick)
        handler.post(animate)
    }

    private fun startAsForeground() {
        val channelId = "temp_overlay"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(channelId, "Температура", NotificationManager.IMPORTANCE_MIN)
        )
        val n = Notification.Builder(this, channelId)
            .setContentTitle("Оверлей температуры работает")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        handler.removeCallbacks(animate)
        if (::prefs.isInitialized) {
            prefs.unregisterOnSharedPreferenceChangeListener(listener)
            prefs.edit().putBoolean("running", false).apply()
        }
        if (::root.isInitialized) wm.removeView(root)
        super.onDestroy()
    }
}
