package com.example.tempoverlay

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import java.io.File

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        } else {
            startForegroundService(Intent(this, TempService::class.java))
        }
        finish()
    }
}

class TempService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var root: FrameLayout
    private lateinit var tint: View
    private lateinit var label: TextView
    private val handler = Handler(Looper.getMainLooper())

    // Температура процессора из системных датчиков (если телефон их отдаёт)
    private fun cpuTemp(): Float? {
        val zones = File("/sys/class/thermal").listFiles { f -> f.name.startsWith("thermal_zone") }
            ?: return null
        val pattern = Regex("cpu|soc|tsens|cluster|big|little|apc")
        var best: Float? = null
        for (z in zones) {
            try {
                val type = File(z, "type").readText().trim().lowercase()
                if (!pattern.containsMatchIn(type) || type.contains("bat")) continue
                var v = File(z, "temp").readText().trim().toFloat()
                if (v > 1000f) v /= 1000f else if (v > 150f) v /= 10f
                if (v in 15f..120f && (best == null || v > best!!)) best = v
            } catch (e: Exception) {
            }
        }
        return best
    }

    private fun batteryTemp(): Float {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
    }

    private val tick = object : Runnable {
        override fun run() {
            val cpu = cpuTemp()
            val t = cpu ?: batteryTemp()
            val low = if (cpu != null) 55f else 35f
            val high = if (cpu != null) 70f else 40f
            val icon = when {
                t < low -> "❄️"
                t < high -> "🌡️"
                else -> "🔥"
            }
            val color = when {
                t < low -> 0xFF1E88E5
                t < high -> 0xFF43A047
                else -> 0xFFE53935
            }.toInt()
            label.text = "$icon\n${"%.0f".format(t)}°" + (if (cpu == null) "*" else "")
            tint.setBackgroundColor(color)
            handler.postDelayed(this, 3000)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val d = resources.displayMetrics.density
        val size = (44 * d).toInt()

        root = FrameLayout(this)
        root.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setOval(0, 0, view.width, view.height)
            }
        }
        root.clipToOutline = true
        root.alpha = 0.6f

        val photo = ImageView(this).apply {
            setImageResource(R.drawable.miku_bg)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        tint = View(this).apply { alpha = 0.4f }
        label = TextView(this).apply {
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 10f
            setShadowLayer(4f, 0f, 0f, Color.BLACK)
        }
        root.addView(photo, FrameLayout.LayoutParams(-1, -1))
        root.addView(tint, FrameLayout.LayoutParams(-1, -1))
        root.addView(label, FrameLayout.LayoutParams(-1, -1))

        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (16 * d).toInt()
            y = (120 * d).toInt()
        }

        // перетаскивание; долгое нажатие без движения закрывает кружок
        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f; var moved = false
        root.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true
                    lp.x = startX + dx
                    lp.y = startY + dy
                    wm.updateViewLayout(root, lp)
                }
                MotionEvent.ACTION_UP ->
                    if (!moved && e.eventTime - e.downTime > 600) stopSelf()
            }
            true
        }

        wm.addView(root, lp)
        handler.post(tick)
    }

    private fun startAsForeground() {
        val channelId = "temp_overlay"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(channelId, "Температура", NotificationManager.IMPORTANCE_MIN)
        )
        val n = Notification.Builder(this, channelId)
            .setContentTitle("Оверлей температуры работает")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        if (::root.isInitialized) wm.removeView(root)
        super.onDestroy()
    }
}
