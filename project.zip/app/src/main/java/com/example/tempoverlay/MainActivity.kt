package com.example.tempoverlay

import android.app.*
import android.content.*
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import java.io.File

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var mainBtn: Button
    private val ACC = 0xFF4DD0E1.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val dm = resources.displayMetrics
        val d = dm.density
        val pad = (20 * d).toInt()

        val frame = FrameLayout(this)
        frame.setBackgroundColor(0xFF14161A.toInt())
        frame.addView(ImageView(this).apply {
            setImageResource(R.drawable.menu_bg)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }, FrameLayout.LayoutParams(-1, -1))

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            background = GradientDrawable().apply {
                setColor(0xCC101216.toInt())
                cornerRadius = 28 * d
            }
        }
        fun label(t: String, size: Float = 16f, color: Int = Color.WHITE) = TextView(this).apply {
            text = t
            textSize = size
            setTextColor(color)
            setPadding(0, (14 * d).toInt(), 0, 0)
        }

        col.addView(TextView(this).apply {
            text = "DATCHIK"
            textSize = 30f
            setTextColor(ACC)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            letterSpacing = 0.12f
        })
        col.addView(TextView(this).apply {
            text = "@BuxaIich"
            textSize = 16f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, (4 * d).toInt(), 0, 0)
        })
        col.addView(label("Температура процессора и GPU поверх игр", 13f, 0xFFB0BEC5.toInt()))

        mainBtn = Button(this).apply {
            textSize = 16f
            setTextColor(0xFF06222A.toInt())
            background = GradientDrawable().apply {
                setColor(ACC)
                cornerRadius = 16 * d
            }
        }
        mainBtn.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            } else if (prefs.getBoolean("running", false)) {
                stopService(Intent(this, TempService::class.java))
                prefs.edit().putBoolean("running", false).apply()
            } else {
                startForegroundService(Intent(this, TempService::class.java))
                prefs.edit().putBoolean("running", true).apply()
            }
            refresh()
        }
        col.addView(mainBtn, LinearLayout.LayoutParams(-1, (52 * d).toInt()).apply {
            topMargin = (18 * d).toInt()
        })

        col.addView(label("Датчики", 13f, 0xFFB0BEC5.toInt()))
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        col.addView(Switch(this).apply {
            text = "Учитывать GPU"
            textSize = 16f
            setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("gpu", true)
            thumbTintList = ColorStateList(states, intArrayOf(ACC, 0xFFB0BEC5.toInt()))
            trackTintList = ColorStateList(states, intArrayOf(0x884DD0E1.toInt(), 0x55FFFFFF))
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("gpu", c).apply() }
        })

        fun seek(key: String, mn: Int, mx: Int, def: Int, title: String, unit: String) {
            val tv = label("")
            val sb = SeekBar(this)
            sb.progressTintList = ColorStateList.valueOf(ACC)
            sb.thumbTintList = ColorStateList.valueOf(ACC)
            sb.max = mx - mn
            sb.progress = prefs.getInt(key, def) - mn
            tv.text = "$title: ${prefs.getInt(key, def)}$unit"
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = p + mn
                    prefs.edit().putInt(key, v).apply()
                    tv.text = "$title: $v$unit"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            col.addView(tv)
            col.addView(sb)
        }
        seek("size", 32, 96, 56, "Размер кружка", " dp")
        seek("alpha", 20, 100, 80, "Видимость", "%")

        col.addView(label("Кружок можно перетаскивать. Долгое нажатие закрывает его.", 13f, 0xFFB0BEC5.toInt()))

        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((14 * d).toInt(), 0, (14 * d).toInt(), (24 * d).toInt())
        }
        outer.addView(View(this), LinearLayout.LayoutParams(-1, (dm.heightPixels * 0.40f).toInt()))
        outer.addView(col)
        frame.addView(ScrollView(this).apply { addView(outer) }, FrameLayout.LayoutParams(-1, -1))
        setContentView(frame)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        mainBtn.text = when {
            !Settings.canDrawOverlays(this) -> "Выдать разрешение «Поверх окон»"
            prefs.getBoolean("running", false) -> "Остановить"
            else -> "Запустить"
        }
    }
}

class TempService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var root: FrameLayout
    private lateinit var tint: View
    private lateinit var label: TextView
    private val handler = Handler(Looper.getMainLooper())

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> applyPrefs() }

    private fun applyPrefs() {
        val d = resources.displayMetrics.density
        val s = (prefs.getInt("size", 56) * d).toInt()
        lp.width = s
        lp.height = s
        root.alpha = prefs.getInt("alpha", 80) / 100f
        if (root.isAttachedToWindow) wm.updateViewLayout(root, lp)
    }

    private fun sensorTemp(names: String): Float? {
        val zones = File("/sys/class/thermal").listFiles { f -> f.name.startsWith("thermal_zone") }
            ?: return null
        val pattern = Regex(names)
        var best: Float? = null
        for (z in zones) {
            try {
                val type = File(z, "type").readText().trim().lowercase()
                if (!pattern.containsMatchIn(type) || type.contains("bat")) continue
                var v = File(z, "temp").readText().trim().toFloat()
                if (v > 1000f) v /= 1000f else if (v > 150f) v /= 10f
                if (v in 15f..120f && (best == null || v > best!!)) best = v
            } catch (e: Exception) {
            }
        }
        return best
    }

    private fun batteryTemp(): Float {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
    }

    private var tC = 0f
    private var tG = -1f
    private var sC = -1f
    private var sG = -1f
    private var gpuOn = true
    private var fromSensor = true

    private fun step(diff: Float) = if (Math.abs(diff) < 0.3f) diff else diff * 0.35f
    private fun f(v: Float) = "%.0f".format(v)

    // раз в 2 секунды читаем реальную температуру
    private val tick = object : Runnable {
        override fun run() {
            val c = sensorTemp("cpu|soc|tsens|cluster|big|little|apc")
            fromSensor = c != null
            tC = c ?: batteryTemp()
            if (sC < 0f) sC = tC
            gpuOn = prefs.getBoolean("gpu", true)
            tG = if (gpuOn) (sensorTemp("gpu") ?: -1f) else -1f
            if (tG < 0f) sG = -1f else if (sG < 0f) sG = tG
            handler.postDelayed(this, 2000)
        }
    }

    // каждые 200 мс плавно, но быстро подтягиваем показание к реальному
    private val animate = object : Runnable {
        override fun run() {
            if (sC >= 0f) {
                sC += step(tC - sC)
                if (sG >= 0f) sG += step(tG - sG)
                val hot = if (sG >= 0f) maxOf(sC, sG) else sC
                val low = if (fromSensor) 55f else 35f
                val high = if (fromSensor) 70f else 40f
                val color = when {
                    hot < low -> 0xFF1E88E5
                    hot < high -> 0xFF43A047
                    else -> 0xFFE53935
                }.toInt()
                if (gpuOn) {
                    label.textSize = 11f
                    label.text = "C ${f(sC)}°\nG " + (if (sG >= 0f) f(sG) + "°" else "--")
                } else {
                    val icon = when {
                        hot < low -> "❄️"
                        hot < high -> "🌡️"
                        else -> "🔥"
                    }
                    label.textSize = 12f
                    label.text = "$icon\n${f(sC)}°" + (if (fromSensor) "" else "*")
                }
                tint.setBackgroundColor(color)
            }
            handler.postDelayed(this, 200)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()

        prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val d = resources.displayMetrics.density
        val size = (prefs.getInt("size", 56) * d).toInt()

        root = FrameLayout(this)
        root.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setOval(0, 0, view.width, view.height)
            }
        }
        root.clipToOutline = true
        root.alpha = prefs.getInt("alpha", 80) / 100f

        val photo = ImageView(this).apply {
            setImageResource(R.drawable.miku_bg)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        tint = View(this).apply { alpha = 0.15f }
        label = TextView(this).apply {
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 12f
            setShadowLayer(6f, 0f, 0f, Color.BLACK)
        }
        root.addView(photo, FrameLayout.LayoutParams(-1, -1))
        root.addView(tint, FrameLayout.LayoutParams(-1, -1))
        root.addView(label, FrameLayout.LayoutParams(-1, -1))

        lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (16 * d).toInt()
            y = (120 * d).toInt()
        }

        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f; var moved = false
        root.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true
                    lp.x = startX + dx
                    lp.y = startY + dy
                    wm.updateViewLayout(root, lp)
                }
                MotionEvent.ACTION_UP ->
                    if (!moved && e.eventTime - e.downTime > 600) stopSelf()
            }
            true
        }

        wm.addView(root, lp)
        prefs.registerOnSharedPreferenceChangeListener(listener)
        handler.post(tick)
        handler.post(animate)
    }

    private fun startAsForeground() {
        val channelId = "temp_overlay"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(channelId, "Температура", NotificationManager.IMPORTANCE_MIN)
        )
        val n = Notification.Builder(this, channelId)
            .setContentTitle("Оверлей температуры работает")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        handler.removeCallbacks(animate)
        if (::prefs.isInitialized) {
            prefs.unregisterOnSharedPreferenceChangeListener(listener)
            prefs.edit().putBoolean("running", false).apply()
        }
        if (::root.isInitialized) wm.removeView(root)
        super.onDestroy()
    }
}
